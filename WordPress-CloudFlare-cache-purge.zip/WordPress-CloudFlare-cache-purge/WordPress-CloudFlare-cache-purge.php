<?php
/**
 * Plugin Name: CloudFlare cache purge
 * Plugin URI: https://github.com/JulianKorgol/WordPress-CloudFlare-cache-purge
 * Description: This plugin allow you to purge CloudFlare Cache by API.
 * Version: 1.0
 * Author: Julian Korgol, Mikołaj Mroczkowski
 * Author URI: https://github.com/JulianKorgol/WordPress-CloudFlare-cache-purge
 * License:     Apache License 2.0
 * License URI: https://github.com/JulianKorgol/WordPress-CloudFlare-cache-purge/blob/main/LICENSE
 */

include_once('scripts/menu.php');
include_once('scripts/menu-removecache.php');

function wccp_remove_cache() {
    ?>
    <div class="notice updated">
        <p>Działa!</p>
    </div>
    <?php
}